from flask import Flask
from flask import render_template
import pymysql

app = Flask(__name__)

'''
@app.route("/")
def hello():
    db = pymysql.connect(host='127.0.0.1', port=3306, user='root', passwd='136071', db='test', charset='utf8')
    cursor = db.cursor()
    sql = 'select * from test.table1'
    cursor.execute(sql)
    result = cursor.fetchall()
    db.close()

    return result[0]
    '''
@app.route("/")
def hello():
    return "<h1> 12조 </h1>"

@app.route("/h")
def hello_h():
    return "<h4>Hellow H</h4>"

@app.route("/univ/<aaa>")
def hello2(aaa):
    a = aaa

@app.route("/<user>")
def test(user):
    return user

@app.route("/test")
def hello_tem():
    return render_template("view.html", aa='전달 데이터', bb="1234", cc=[1,2,3])

@app.route("/hello/<user>")
def hello_name(user):
    return render_template("view.html", data=user, list=[1,2,3,4])

@app.route("/index")
def index():
    return render_template("index.html")


if __name__ == "__main__":
    app.run()
